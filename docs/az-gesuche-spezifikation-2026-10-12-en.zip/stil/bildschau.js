/* Bildschau — ein Diagramm gross und zoombar.
 *
 * In der Seite passt sich ein Diagramm der Breite an. Wer es lesen will,
 * tippt es an; dann oeffnet sich diese Schau, und das Bild laesst sich
 * kneifen, ziehen und doppeltippen — dieselben drei Gesten wie in der
 * Claude-App, nur hier in der Seite statt in einer Android-Ansicht.
 *
 * WARUM EIGENE GESTEN UND NICHT DER ZOOM DER WEBVIEW: Der vergroessert
 * die ganze Seite samt Leiste und Text. Hier soll nur das Bild wachsen,
 * und das Schliessen soll das Geleistete nicht mitnehmen.
 *
 * WARUM EIN HISTORY-EINTRAG: Auf dem Telefon ist die Zuruecktaste die
 * erste Geste zum Schliessen. Ohne Eintrag verliesse sie die Seite.
 *
 * Keine Abhaengigkeit, kein Netz — das Werk wird offline gelesen.
 */
(function () {
  'use strict';

  var MAX = 8, MIN = 1;
  var schau, bild, z = 1, x = 0, y = 0;
  var start = null, letzterTipp = 0;

  function setzen() {
    bild.style.transform =
      'translate(' + x + 'px,' + y + 'px) scale(' + z + ')';
  }

  /* Nach dem Zoomen darf das Bild nicht aus dem Fenster wandern: Was
     breiter ist als das Fenster, darf verschoben werden, was schmaler
     ist, bleibt mittig. */
  function zaeumen() {
    var r = bild.getBoundingClientRect();
    var b = bild.offsetWidth * z, h = bild.offsetHeight * z;
    var fx = window.innerWidth, fy = window.innerHeight;
    if (b <= fx) { x = (fx - b) / 2; } else {
      x = Math.min(0, Math.max(fx - b, x));
    }
    if (h <= fy) { y = (fy - h) / 2; } else {
      y = Math.min(0, Math.max(fy - h, y));
    }
    void r;
  }

  function zoomen(faktor, px, py) {
    var neu = Math.min(MAX, Math.max(MIN, z * faktor));
    if (neu === z) return;
    /* Um den Punkt zwischen den Fingern vergroessern, nicht um die Ecke. */
    x = px - (px - x) * (neu / z);
    y = py - (py - y) * (neu / z);
    z = neu;
    zaeumen();
    setzen();
  }

  function anpassen() {
    z = MIN; x = 0; y = 0;
    zaeumen();
    setzen();
  }

  function schliessen(ausHistory) {
    if (!schau) return;
    document.body.classList.remove('schau-offen');
    schau.remove();
    schau = null; bild = null;
    document.removeEventListener('keydown', aufTaste);
    if (!ausHistory && history.state && history.state.schau) history.back();
  }

  function aufTaste(e) {
    if (e.key === 'Escape') schliessen(false);
  }

  function abstand(t) {
    var dx = t[0].clientX - t[1].clientX, dy = t[0].clientY - t[1].clientY;
    return Math.sqrt(dx * dx + dy * dy);
  }

  function oeffnen(quelle) {
    schau = document.createElement('div');
    schau.className = 'schau';

    bild = document.createElement('img');
    bild.src = quelle.getAttribute('src');
    bild.alt = quelle.alt || '';

    var zu = document.createElement('button');
    zu.className = 'zu';
    zu.setAttribute('aria-label', 'Schliessen');
    zu.textContent = '×';
    zu.addEventListener('click', function () { schliessen(false); });

    var hinweis = document.createElement('p');
    hinweis.className = 'hinweis';
    hinweis.textContent =
      'Kneifen zum Vergrössern · Doppeltippen springt · Zurück schliesst';

    schau.appendChild(bild);
    schau.appendChild(zu);
    schau.appendChild(hinweis);
    document.body.appendChild(schau);
    document.body.classList.add('schau-offen');
    document.addEventListener('keydown', aufTaste);
    history.pushState({ schau: true }, '');

    bild.addEventListener('load', anpassen);
    if (bild.complete) anpassen();

    /* Ein Tipp auf den Hintergrund schliesst, einer auf das Bild nicht. */
    schau.addEventListener('click', function (e) {
      if (e.target === schau) schliessen(false);
    });

    schau.addEventListener('touchstart', function (e) {
      if (e.touches.length === 2) {
        start = { d: abstand(e.touches), z: z };
      } else if (e.touches.length === 1) {
        start = {
          x: e.touches[0].clientX - x,
          y: e.touches[0].clientY - y,
          t: Date.now()
        };
      }
    }, { passive: true });

    schau.addEventListener('touchmove', function (e) {
      if (!start) return;
      e.preventDefault();
      if (e.touches.length === 2 && start.d) {
        var mitte = {
          x: (e.touches[0].clientX + e.touches[1].clientX) / 2,
          y: (e.touches[0].clientY + e.touches[1].clientY) / 2
        };
        var faktor = (abstand(e.touches) / start.d) * (start.z / z);
        zoomen(faktor, mitte.x, mitte.y);
      } else if (e.touches.length === 1 && start.x !== undefined) {
        x = e.touches[0].clientX - start.x;
        y = e.touches[0].clientY - start.y;
        zaeumen();
        setzen();
      }
    }, { passive: false });

    schau.addEventListener('touchend', function (e) {
      if (e.touches.length === 0 && start && start.t &&
          Date.now() - start.t < 250) {
        var jetzt = Date.now();
        if (jetzt - letzterTipp < 320) {
          var p = e.changedTouches[0];
          if (z > MIN + 0.01) { anpassen(); }
          else { zoomen(2.5, p.clientX, p.clientY); }
          letzterTipp = 0;
        } else {
          letzterTipp = jetzt;
        }
      }
      start = null;
    }, { passive: true });

    /* Mit der Maus: Rad zoomt, Doppelklick springt. */
    schau.addEventListener('wheel', function (e) {
      e.preventDefault();
      zoomen(e.deltaY < 0 ? 1.18 : 1 / 1.18, e.clientX, e.clientY);
    }, { passive: false });

    bild.addEventListener('dblclick', function (e) {
      if (z > MIN + 0.01) anpassen();
      else zoomen(2.5, e.clientX, e.clientY);
    });
  }

  window.addEventListener('popstate', function () {
    if (schau) schliessen(true);
  });

  function anmelden() {
    var bilder = document.querySelectorAll('.diagramm img');
    for (var i = 0; i < bilder.length; i++) {
      if (bilder[i].dataset.schau) continue;
      bilder[i].dataset.schau = '1';
      bilder[i].addEventListener('click', function (e) {
        e.preventDefault();
        oeffnen(e.currentTarget);
      });
    }
  }

  /* mkdocs-material tauscht bei "instant navigation" nur den Inhalt aus;
     deshalb nicht nur einmal beim Laden anmelden. */
  if (window.document$ && window.document$.subscribe) {
    window.document$.subscribe(anmelden);
  } else if (document.readyState !== 'loading') {
    anmelden();
  } else {
    document.addEventListener('DOMContentLoaded', anmelden);
  }
})();
